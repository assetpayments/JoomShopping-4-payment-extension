<div class="col100">
<fieldset class="adminform">
<table class="admintable" width = "100%" >
 <tr>
   <td  class="key">
     <?php echo _JSHOP_ASSETPAYMENTS_MERCHANT_ID;?>
   </td>
   <td>
     <input type = "text" class = "inputbox" name = "pm_params[merchant_id]" size="45" value = "<?php echo $params['merchant_id']?>" />
   </td>
 </tr>
 <tr>
   <td  class="key">

     <?php echo _JSHOP_ASSETPAYMENTS_SECRET_KEY;?>
   </td>
   <td>
     <input type = "password" class = "inputbox" name = "pm_params[secret_key]" size="45" value = "<?php echo $params['secret_key']?>" />
   </td>
 </tr>
 <tr>
   <td  class="key">

     <?php echo _JSHOP_ASSETPAYMENTS_TEMPLATE_ID;?>
   </td>
   <td>
     <input type = "text" class = "inputbox" name = "pm_params[template_id]" size="45" value = "<?php echo $params['template_id']?>" />
   </td>
 </tr>

 <tr>
   <td class="key">
      <?php echo _JSHOP_ASSETPAYMENTS_TRANSACTION_SUCCESSFUL_DESCRIPTION;?>
   </td>
   <td>
     <?php              
         print JHTML::_('select.genericlist', $orders->getAllOrderStatus(), 'pm_params[transaction_end_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_end_status'] );
     ?>
   </td>
 </tr>
 <tr>
     <td class="key">
      <?php echo _JSHOP_ASSETPAYMENTS_TRANSACTION_PENDING_DESCRIPTION;?>
   </td>
   <td>
     <?php 
         echo JHTML::_('select.genericlist',$orders->getAllOrderStatus(), 'pm_params[transaction_pending_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_pending_status']);
     ?>
   </td>
 </tr>
 <tr>
     <td class="key">
      <?php echo _JSHOP_ASSETPAYMENTS_TRANSACTION_FAILED_DESCRIPTION;?>
   </td>
   <td>
     <?php 
     echo JHTML::_('select.genericlist',$orders->getAllOrderStatus(), 'pm_params[transaction_failed_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_failed_status']);
     ?>
   </td>
 </tr>
</table>
</fieldset>   
<div class="clr"></div>

