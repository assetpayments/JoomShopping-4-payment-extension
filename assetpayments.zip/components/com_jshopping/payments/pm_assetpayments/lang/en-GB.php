<?php

defined('_JEXEC') or die();

define('_JSHOP_ASSETPAYMENTS_MERCHANT_ID', 'Merchant ID');
define('_JSHOP_ASSETPAYMENTS_TEMPLATE_ID', 'Template ID');
define('_JSHOP_ASSETPAYMENTS_SECRET_KEY', 'Secret key');
define('_JSHOP_ASSETPAYMENTS_TRANSACTION_SUCCESSFUL_DESCRIPTION','Successful payment status.');
define('_JSHOP_ASSETPAYMENTS_TRANSACTION_PENDING_DESCRIPTION','Pending (not completed) payment status.');
define('_JSHOP_ASSETPAYMENTS_TRANSACTION_FAILED_DESCRIPTION','Failed payment status.');
define('_JSHOP_ASSETPAYMENTS_REDIRECT_TO_PAYMENT_PAGE', 'Redirecting to the Payment page, please wait...');