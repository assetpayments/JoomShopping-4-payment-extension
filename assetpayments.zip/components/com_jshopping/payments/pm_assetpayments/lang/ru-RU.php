<?php

defined('_JEXEC') or die();

define('_JSHOP_ASSETPAYMENTS_MERCHANT_ID', 'ID мерчанта');
define('_JSHOP_ASSETPAYMENTS_TEMPLATE_ID', 'ID шаблона');
define('_JSHOP_ASSETPAYMENTS_SECRET_KEY', 'Секретный ключ');
define('_JSHOP_ASSETPAYMENTS_TRANSACTION_SUCCESSFUL_DESCRIPTION','Статус успешной оплаты.');
define('_JSHOP_ASSETPAYMENTS_TRANSACTION_PENDING_DESCRIPTION','Статус, если оплата не завершена.');
define('_JSHOP_ASSETPAYMENTS_TRANSACTION_FAILED_DESCRIPTION','Статус ошибочной оплаты.');
define('_JSHOP_ASSETPAYMENTS_REDIRECT_TO_PAYMENT_PAGE', 'Перенаправление на страницу оплаты...');