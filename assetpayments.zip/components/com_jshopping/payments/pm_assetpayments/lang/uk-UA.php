<?php


defined('_JEXEC') or die();

define('_JSHOP_ASSETPAYMENTS_MERCHANT_ID', 'ID мерчанта');
define('_JSHOP_ASSETPAYMENTS_SECRET_KEY', 'Секретный ключ');
define('_JSHOP_ASSETPAYMENTS_TRANSACTION_SUCCESSFUL_DESCRIPTION','Статус вдалої оплати.');
define('_JSHOP_ASSETPAYMENTS_TRANSACTION_PENDING_DESCRIPTION','Статус, якщо оплата не завершена.');
define('_JSHOP_ASSETPAYMENTS_TRANSACTION_FAILED_DESCRIPTION','Статус помилковою оплати.');
define('_JSHOP_ASSETPAYMENTS_REDIRECT_TO_PAYMENT_PAGE', 'Перенаправлення на сторінку оплати...');