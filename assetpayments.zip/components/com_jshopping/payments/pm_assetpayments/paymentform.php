<?php 
defined('_JEXEC') or die('Restricted access'); 
?>
<script type="text/javascript">
function check_pm_assetpayments(){
    jQuery('#payment_form').submit();
}
</script>