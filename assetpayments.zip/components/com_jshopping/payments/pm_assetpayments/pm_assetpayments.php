﻿<?php

defined('_JEXEC') or die('Restricted access');



class pm_assetpayments extends PaymentRoot
{
    

  function showPaymentForm($params, $pmconfigs){
        include(dirname(__FILE__)."/paymentform.php");
    }

 

	function loadLanguageFile()
	{
		$lang = JFactory::getLanguage();
		$langtag = $lang->getTag(); 

		if (file_exists(JPATH_ROOT.'/components/com_jshopping/payments/pm_assetpayments/lang/'.$langtag.'.php')) {
			require_once(JPATH_ROOT.'/components/com_jshopping/payments/pm_assetpayments/lang/'.$langtag.'.php');
		} else { 
			require_once(JPATH_ROOT.'/components/com_jshopping/payments/pm_assetpayments/lang/en-GB.php');
		}
	}

    function showAdminFormParams($params)
    {
        

          $orders = JSFactory::getModel('orders', 'JshoppingModel'); 
          $this->loadLanguageFile();
        include(dirname(__FILE__)."/adminparamsform.php");	
    }


    function checkTransaction($pmconfigs, $order, $act)
    {



  
$jshopConfig = JSFactory::getConfig();
$session = JFactory::getSession();
$order_id = $session->get('jshop_end_order_id');
$order = JTable::getInstance('order', 'jshop');
$order->load($order_id);
$items = $order->getAllItems();
$cart = JSFactory::getModel('cart', 'jshop');
$cart->load();  

             

	
        $merchant_id = $pmconfigs['merchant_id'];
        $secret_key = $pmconfigs['secret_key'];
	$order_id = $order->order_id;	
        $mode = "2CO";
        $type = "product";
        $baseUri = JUri::base();
        $back_url =  "index.php?option=com_jshopping&controller=checkout&task=step7&js_paymentclass=pm_assetpayments";
        $receipt_link = $baseUri.$back_url;


$secret_key = $pmconfigs['secret_key'];


$hashSecretWord = $secret_key; 
$hashSid = JRequest::getVar('sid'); 
$hashOrder = JRequest::getVar('order_number'); 
$hashTotal = JRequest::getVar('total');

                       

if ($pmconfigs['test']){

$StringToHash = mb_strtoupper(md5($hashSecretWord . $hashSid . 1 . $hashTotal));

 } else{
$StringToHash = mb_strtoupper(md5($hashSecretWord . $hashSid . $hashOrder . $hashTotal));

}

              
	if ($StringToHash != JRequest::getVar('key'))
{

return array(0, _JSHOP_ERROR_PAYMENT);

}
else 
{

return array(1, 'Successful payment order #'.$order->order_id.'.');

    }

}


    function showEndForm($pmconfigs, $order)
    {
        
		$jshopConfig = JSFactory::getConfig();
		$lang = JSFactory::getLang();
		$session = JFactory::getSession();
		$order_id = $session->get('jshop_end_order_id');
		$order = JTable::getInstance('order', 'jshop');
		$order->load($order_id);
		$items = $order->getAllItems();
		$cart = JSFactory::getModel('cart', 'jshop');
		$cart->load(); 
 
		$user_country = JTable::getInstance('country', 'jshop');
			   $user_country->load($order->country);
			   $usercountry = $user_country->country_code_2;

		$del_country = JTable::getInstance('country', 'jshop');
			   $del_country->load($order->d_country);
			   $delcountry = $del_country->country_code_2;
		
		$shippingMethod = JTable::getInstance('shippingMethod', 'jshop');
		$shippingMethod->load($order->shipping_method_id);
		$name = $lang->get("name");
		
		$baseUri = JUri::base();
        
        $callback_url =  "index.php?option=com_jshopping&controller=checkout&task=step7&js_paymentclass=pm_assetpayments";		
        $return_url =  "index.php?option=com_jshopping&controller=checkout&task=step7&act=return&js_paymentclass=pm_assetpayments";		
        $img_url =  "components/com_jshopping/files/img_products/";        
        $callback = $baseUri.$callback_url;
        $return = $baseUri.$return_url;
		
		$jversion = new JVersion;
		$j_version = $jversion->getShortVersion();
		$xml_url = "administrator/components/com_jshopping/jshopping.xml";
		$jmsh_url = $baseUri.$xml_url;
		
		$xmldata = simplexml_load_file($jmsh_url);
		$jmsh_version = $xmldata->version;
		//echo $xmldata->employee[1]->firstname; 
		
		
		//****Required variables****//	
		$option['TemplateId'] = $pmconfigs['template_id'];
		$option['CustomMerchantInfo'] = 'Joomla '.$j_version. '/ JoomShopping '.$jmsh_version;
		$option['MerchantInternalOrderId'] = $order->order_id;
		$option['StatusURL'] = $callback;	
		$option['ReturnURL'] = $return;
		$option['AssetPaymentsKey'] = $pmconfigs['merchant_id'];
		$option['Amount'] = number_format($order->order_total, 2, '.', '');	
		$option['Currency'] = $order->currency_code_iso;
		$option['CountryISO'] = 'UKR';
		$option['IpAddress'] = $order->ip_address;
		
		var_dump ($option);
		
		//****Phone fix****//
		If ($order->phone ==''){
			$phone = $order->mobil_phone;
		}else {
			$phone = $order->phone;
		}
		
		//****Customer data and address****//
		$option['FirstName'] = $order->f_name;
		$option['LastName'] = $order->l_name;
        $option['Email'] = $order->email;
        $option['Phone'] = $phone;
        $option['Address'] = $order->street . ', ' . $order->city. ', ' . $order->zip. ', ' . $usercountry;
        $option['City'] = $order->city;
        $option['ZIP'] = $order->zip;
        $option['Region'] = $order->state;
        $option['COUNTRY'] = $usercountry;
		
		//****Adding cart details****//
		$i = 0; 
		foreach ($items as $item){
			$option['Products'][] = array(
				'ProductId' => $order->product_id,
				'ProductName' => $item->product_name,
				'ProductPrice' => number_format((float)$item->product_item_price, 2, '.', ''),
				'ProductItemsNum' => number_format((float)$item->product_quantity, 0),
				//'ImageUrl' => 'https://assetpayments.com/dist/css/images/product.png',
				'ImageUrl' => $baseUri.$img_url.$item->thumb_image,
			);
			$i++;
		}
		
		//****Adding shipping method****//
		$option['Products'][] = array(
				'ProductId' => '1',
				'ImageUrl' => 'https://assetpayments.com/dist/css/images/delivery.png',
				'ProductItemsNum' => 1,
				'ProductName' => $shippingMethod->$name,						
				'ProductPrice' => number_format((float)$order->order_shipping, 2, '.', ''), 					
			);
		
		//****Create pending order ****//
		require_once('configuration.php');
		$conf = new JConfig;		
		$mysql = mysql_connect($conf->host,$conf->user,$conf->password);
		mysql_select_db($conf->db);
		$prefix = $conf->dbprefix;		
		mysql_query("UPDATE ".$prefix."jshopping_orders SET order_created='1',order_status='".$pmconfigs['transaction_pending_status']."' WHERE order_id='$order_id'");
		
		
		$data = base64_encode( json_encode($option) );		
       
?>
	<html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />            
        </head>
        <body>
		
		<form method="POST" id="paymentform" name = "paymentform" action="https://assetpayments.us/checkout/pay" style="display:none;">
            <input type="hidden" name="data" value="<?php print $data?>" />
        </form>

 <?php print _JSHOP_REDIRECT_TO_PAYMENT_PAGE;?>

        <br>
        <script type="text/javascript">document.getElementById('paymentform').submit();</script>
        </body>
        </html>
         <?php
        die();
	}
	
    function getUrlParams($pmconfigs)
    {                        
        
		require_once('configuration.php');
		$conf = new JConfig;
		
		$mysql = mysql_connect($conf->host,$conf->user,$conf->password);
		mysql_select_db($conf->db);
		$prefix = $conf->dbprefix;
		
		$json = json_decode(file_get_contents('php://input'), true);
			
		$key = $pmconfigs['merchant_id'];
		$secret = $pmconfigs['secret_key'];
		$transactionId = $json['Payment']['TransactionId'];
		$signature = $json['Payment']['Signature'];
		$order_id = $json['Order']['OrderId'];
		$status = $json['Payment']['StatusCode'];
		
		$requestSign =$key.':'.$transactionId.':'.strtoupper($secret);
		$sign = hash_hmac('md5',$requestSign,$secret);
		
		if ($status == 1 && $sign == $signature) {
			mysql_query("UPDATE ".$prefix."jshopping_orders SET order_created='1',order_status='".$pmconfigs['transaction_end_status']."' WHERE order_id='$order_id'"); 
			mysql_query("UPDATE ".$prefix."jshopping_order_history SET comments='Transaction ID: ".$transactionId."' WHERE order_id='$order_id'"); 
		} 
		if ($status == 2 && $sign == $signature) {
			mysql_query("UPDATE ".$prefix."jshopping_orders SET order_created='1',order_status='".$pmconfigs['transaction_failed_status']."' WHERE order_id='$order_id'"); 
			mysql_query("UPDATE ".$prefix."jshopping_order_history SET comments='Transaction ID: ".$transactionId."' WHERE order_id='$order_id'"); 
		} 
		
		
		
		
    }
    
}
?>