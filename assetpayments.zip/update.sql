INSERT INTO `#__jshopping_payment_method` (`name_en-GB`, `name_ru-RU`, `payment_code`, `payment_class`, `scriptname`, `payment_publish`, `payment_ordering`, `payment_params`, `payment_type`, `price`, `price_type`, `tax_id`, `show_descr_in_email`) VALUES
('Pay by card Visa/Mastercard (AssetPayments)',   'Оплатить картой Visa/Mastercard (AssetPayments)',  'assetpayments', 'pm_assetpayments' , 'pm_assetpayments', 1, 3, 'merchant_id=XXXXXXXXXXX\nsecret_key=XXXXXXXXXXX\ntemplate_id=19\ntransaction_end_status=7\ntransaction_pending_status=1\ntransaction_failed_status=3\n\n', 2, 0.00, 1, 1, 0);
UPDATE `#__jshopping_payment_method` SET `image` = '/components/com_jshopping/payments/pm_assetpayments/pay_logo/asset.png' WHERE `payment_class` = 'pm_assetpayments';



